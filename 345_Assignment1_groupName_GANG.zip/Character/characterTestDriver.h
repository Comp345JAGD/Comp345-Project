#ifndef CHARACTER_TEST_DRIVER_H
#define CHARACTER_TEST_DRIVER_H

#include "dice.h"
#include "character.h"
#include "fighter.h"
#include <limits>
using std::cin;
using std::cout;
using std::string;

void characterTestDriver();

#endif // CHARACTER_TEST_DRIVER_H