#ifndef _DICE2_H
#define _DICE2_H
#include <iostream>

int RollDice(std::string diceRoll);

#endif