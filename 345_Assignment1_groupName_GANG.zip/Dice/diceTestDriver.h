#ifndef _DICE_TEST_DRIVER_H
#define _DICE_TEST_DRIVER_H

#include <iostream>
#include "dice2.h"
using namespace std;

void diceTestDriver();

#endif